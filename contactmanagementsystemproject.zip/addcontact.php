<?php
// Database connection config
$servername = "localhost";
$username = "root"; // Change if needed
$password = "";     // Change if your MySQL has a password
$dbname = "contact_management"; // Make sure this database exists

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check DB connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form was submitted
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // Retrieve form data safely
    $full_name = $_POST['full_name'];
    $phone_number = $_POST['phone_number'];
    $email = $_POST['email'];

    // Prepare SQL statement
    $stmt = $conn->prepare("INSERT INTO contacts (full_name, phone_number, email) VALUES (?, ?, ?)");


    if ($stmt) {
        // Bind parameters (s = string)
        $stmt->bind_param("sss", $full_name, $phone_number, $email);

        // Execute the query
        if ($stmt->execute()) {
            echo "<script>
                    alert('Contact added successfully!');
                    window.location.href='contact.html';
                  </script>";
        } else {
            echo "Error: Could not execute the query. " . $stmt->error;
        }

        // Close statement
        $stmt->close();
    } else {
        echo "Error: Could not prepare the statement. " . $conn->error;
    }
} else {
    echo "Invalid request method.";
}

// Close DB connection
$conn->close();
?>
