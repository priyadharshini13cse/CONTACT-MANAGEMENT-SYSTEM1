<?php
session_start();

$host = "localhost";
$user = "root";  
$pass = "";  
$dbname = "contact_management";  

// Database connection
$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    die("<script>alert('Database Connection Failed: " . $conn->connect_error . "'); window.location='login.html';</script>");
}

// Handle Login
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["login"])) {
    $email = trim($_POST["email"]);
    $password = trim($_POST["password"]);

    // Check if email exists
    $sql = "SELECT * FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        echo "<script>alert('Database Error: " . $conn->error . "'); window.location='login.html';</script>";
        exit();
    }

    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    // If user exists, verify password
    if ($result->num_rows === 1) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row["password"])) {
            $_SESSION["user_email"] = $row["email"];

            // ✅ Redirect to home.html upon successful login
            echo "<script>alert('Login successful! Redirecting to Home.'); window.location='home.html';</script>";
        } else {
            echo "<script>alert('Invalid password!'); window.location='login.html';</script>";
        }
    } else {
        echo "<script>alert('User not found! Please register first.'); window.location='register.html';</script>";
    }

    $stmt->close();
}

$conn->close();
?>